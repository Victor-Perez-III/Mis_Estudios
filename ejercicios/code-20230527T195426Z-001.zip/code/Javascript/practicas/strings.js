let tipe = 'mozilla'


// includes()--> este metodo funciona para buscar que palabara existe en un string
let hola = tipe.includes('hola')
console.log(hola);

//startsWith() --> Este metodo funciona para revisar con que palaba comiensa un string
let start = tipe.startsWith('d')
console.log(start);

// endsWith() --> este metodo funcina para revisar con que palabra o letra finaliza un string
let end = tipe.endsWith('a')
console.log(end);